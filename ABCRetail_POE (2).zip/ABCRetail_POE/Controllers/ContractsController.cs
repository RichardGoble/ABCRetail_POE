﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail_POE.Services;

namespace ABCRetail_POE.Controllers
{
    public class ContractsController : Controller
    {
        private readonly FunctionIntegrationService _functions;

        public ContractsController(FunctionIntegrationService functions)
        {
            _functions = functions;
        }

        public IActionResult Index() => View();

        public IActionResult Upload() => View();

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile? contractFile)
        {
            if (contractFile == null) return RedirectToAction("Index");

            using var stream = contractFile.OpenReadStream();
            await _functions.UploadToFileShareAsync(stream, contractFile.FileName);

            return RedirectToAction("Index");
        }
    }
}
