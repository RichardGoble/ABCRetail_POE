﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail_POE.Services;
using ABCRetail_POE.Models;

namespace ABCRetail_POE.Controllers
{
    public class OrdersController : Controller
    {
        private readonly FunctionIntegrationService _functions;

        public OrdersController(FunctionIntegrationService functions)
        {
            _functions = functions;
        }

        public IActionResult Index() => View();

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(OrderEntity model)
        {
            if (!ModelState.IsValid) return View(model);

            model.RowKey = Guid.NewGuid().ToString();
            model.Status = "New";
            model.Total = model.Quantity * model.Price;

            // store order in table
            await _functions.StoreToTableAsync(model);

            // send queue message
            var msg = $"OrderCreated|OrderId:{model.RowKey}|Cust:{model.CustomerId}|Prod:{model.ProductId}|Qty:{model.Quantity}|Price:{model.Price}|Total:{model.Total}";
            await _functions.EnqueueMessageAsync(msg);

            return RedirectToAction("Index");
        }
    }
}
