﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail_POE.Services;
using ABCRetail_POE.Models;

namespace ABCRetail_POE.Controllers
{
    public class PaymentsController : Controller
    {
        private readonly FunctionIntegrationService _functions;

        public PaymentsController(FunctionIntegrationService functions)
        {
            _functions = functions;
        }

        public IActionResult Index() => View();

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(PaymentEntity model)
        {
            if (!ModelState.IsValid) return View(model);

            await _functions.StoreToTableAsync(model);
            return RedirectToAction("Index");
        }
    }
}
