﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail_POE.Services;
using ABCRetail_POE.Models;

namespace ABCRetail_POE.Controllers
{
    public class ProductsController : Controller
    {
        private readonly FunctionIntegrationService _functions;

        public ProductsController(FunctionIntegrationService functions)
        {
            _functions = functions;
        }

        public IActionResult Index() => View(); // no local fetch needed (data is in Azure)

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(ProductEntity model, IFormFile? image)
        {
            if (!ModelState.IsValid) return View(model);

            if (image != null)
            {
                using var stream = image.OpenReadStream();
                await _functions.UploadToBlobAsync(stream, image.FileName);
                model.ImageFileName = image.FileName;
                model.ImageUrl = $"https://st10083358storageaccount.blob.core.windows.net/productimages/{image.FileName}";
            }

            await _functions.StoreToTableAsync(model);
            return RedirectToAction("Index");
        }
    }
}
