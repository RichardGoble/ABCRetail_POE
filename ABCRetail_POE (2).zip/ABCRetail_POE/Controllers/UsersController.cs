﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail_POE.Services;
using ABCRetail_POE.Models;

namespace ABCRetail_POE.Controllers
{
    public class UsersController : Controller
    {
        private readonly TableStorageService _table;
        public UsersController(TableStorageService table) => _table = table;

        public async Task<IActionResult> Index()
        {
            var list = await _table.GetUsersAsync();
            return View(list);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(UserEntity model)
        {
            if (!ModelState.IsValid) return View(model);
            await _table.CreateOrUpdateUserAsync(model);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _table.DeleteUserAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
