﻿using Azure;
using Azure.Data.Tables;

namespace ABCRetail_POE.Models
{
    public class OrderEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "Order";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }

        public string? CustomerId { get; set; }
        public string? ProductId { get; set; }

        public int Quantity { get; set; }
        public double Price { get; set; }     // 👈 new field
        public double Total { get; set; }     // calculated in controller

        public string? Status { get; set; } = "New";
    }
}
