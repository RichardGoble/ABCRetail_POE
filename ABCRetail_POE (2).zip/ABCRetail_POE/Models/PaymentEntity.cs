﻿using Azure;
using Azure.Data.Tables;

namespace ABCRetail_POE.Models
{
    public class PaymentEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "Payment";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }

        public string? OrderId { get; set; }
        public string? Method { get; set; }
        public double Amount { get; set; }
        public string? Status { get; set; }
    }
}
