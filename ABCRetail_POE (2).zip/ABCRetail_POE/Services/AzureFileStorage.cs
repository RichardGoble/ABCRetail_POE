﻿using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Microsoft.Extensions.Options;

namespace ABCRetail_POE.Services
{
    public class AzureFileStorage
    {
        private readonly ShareClient _share;

        public AzureFileStorage(IOptions<AzureStorageOptions> opts)
        {
            var o = opts.Value;
            _share = new ShareClient(o.ConnectionString, o.FileShare ?? "contracts");
            _share.CreateIfNotExists();
        }

        public async Task UploadFileAsync(IFormFile file, string? directory = null)
        {
            var root = _share.GetRootDirectoryClient();
            ShareDirectoryClient dir = root;
            if (!string.IsNullOrEmpty(directory))
            {
                dir = root.GetSubdirectoryClient(directory);
                await dir.CreateIfNotExistsAsync();
            }

            var fileClient = dir.GetFileClient(file.FileName);
            using var s = file.OpenReadStream();
            await fileClient.CreateAsync(s.Length);
            await fileClient.UploadRangeAsync(new HttpRange(0, s.Length), s);
        }

        public async Task<List<string>> ListFilesAsync(string? directory = null)
        {
            var list = new List<string>();
            var root = _share.GetRootDirectoryClient();
            ShareDirectoryClient dir = root;
            if (!string.IsNullOrEmpty(directory)) dir = root.GetSubdirectoryClient(directory);

            await foreach (var item in dir.GetFilesAndDirectoriesAsync())
            {
                if (!item.IsDirectory) list.Add(item.Name);
            }
            return list;
        }

        public Uri GetFileUri(string fileName, string? directory = null)
        {
            var root = _share.GetRootDirectoryClient();
            ShareDirectoryClient dir = root;
            if (!string.IsNullOrEmpty(directory)) dir = root.GetSubdirectoryClient(directory);
            return dir.GetFileClient(fileName).Uri;
        }
    }
}

