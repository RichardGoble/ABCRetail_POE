﻿namespace ABCRetail_POE.Services
{
    public class AzureStorageOptions
    {
        public string? ConnectionString { get; set; }
        public string? BlobContainerName { get; set; }
        public string? QueueName { get; set; }
        public string? FileShare { get; set; }
        public TablesOptions? Tables { get; set; }
    }

    public class TablesOptions
    {
        public string? Customers { get; set; }
        public string? Products { get; set; }
        public string? Orders { get; set; }
        public string? Payments { get; set; }
    }
}