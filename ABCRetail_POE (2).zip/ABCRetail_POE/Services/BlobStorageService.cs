﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Options;

namespace ABCRetail_POE.Services
{
    public class BlobStorageService
    {
        private readonly BlobContainerClient _container;

        public BlobStorageService(IOptions<AzureStorageOptions> opts)
        {
            var o = opts.Value;
            var serviceClient = new BlobServiceClient(o.ConnectionString);
            _container = serviceClient.GetBlobContainerClient(o.BlobContainerName ?? "productimages");
            _container.CreateIfNotExists();
        }

        // Return both file name and full URI
        public async Task<(string FileName, string Uri)> UploadFileAsync(IFormFile file, string? fileName = null)
        {
            fileName ??= $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var blob = _container.GetBlobClient(fileName);
            using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, overwrite: true);
            return (fileName, blob.Uri.ToString());
        }

        public Uri GetBlobUri(string fileName) => _container.GetBlobClient(fileName).Uri;
    }
}
