﻿using System.Net.Http.Json;
using ABCRetail_POE.Models;

namespace ABCRetail_POE.Services
{
    public class FunctionIntegrationService
    {
        private readonly HttpClient _http;
        private readonly IConfiguration _config;

        public FunctionIntegrationService(HttpClient http, IConfiguration config)
        {
            _http = http;
            _config = config;
        }

        public async Task<bool> StoreToTableAsync<T>(T entity)
        {
            var url = _config["FunctionEndpoints:TableFunction"];
            var response = await _http.PostAsJsonAsync(url, entity);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UploadToBlobAsync(Stream fileStream, string fileName)
        {
            var url = $"{_config["FunctionEndpoints:BlobFunction"]}&filename={fileName}";
            var content = new StreamContent(fileStream);
            var response = await _http.PostAsync(url, content);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EnqueueMessageAsync(object message)
        {
            var url = _config["FunctionEndpoints:QueueFunction"];
            var response = await _http.PostAsJsonAsync(url, message);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UploadToFileShareAsync(Stream fileStream, string fileName)
        {
            var url = $"{_config["FunctionEndpoints:FileFunction"]}&filename={fileName}";
            var content = new StreamContent(fileStream);
            var response = await _http.PostAsync(url, content);
            return response.IsSuccessStatusCode;
        }
    }
}
