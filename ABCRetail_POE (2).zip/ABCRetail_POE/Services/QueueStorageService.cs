﻿using Azure.Storage.Queues;
using Microsoft.Extensions.Options;

namespace ABCRetail_POE.Services
{
    public class QueueStorageService
    {
        private readonly QueueClient _queue;

        public QueueStorageService(IOptions<AzureStorageOptions> opts)
        {
            var o = opts.Value;
            _queue = new QueueClient(o.ConnectionString, o.QueueName ?? "orderqueue");
            _queue.CreateIfNotExists();
        }

        public async Task EnqueueMessageAsync(string message)
        {
            // QueueClient will base64-encode message if necessary; explicitly encode for safety
            var bytes = System.Text.Encoding.UTF8.GetBytes(message);
            var encoded = Convert.ToBase64String(bytes);
            await _queue.SendMessageAsync(encoded);
        }
    }
}
