﻿using Azure.Data.Tables;
using Microsoft.Extensions.Options;
using ABCRetail_POE.Models;

namespace ABCRetail_POE.Services
{
    public class TableStorageService
    {
        private readonly TableServiceClient _tableService;
        private readonly AzureStorageOptions _opts;

        public TableStorageService(IOptions<AzureStorageOptions> o)
        {
            _opts = o.Value;
            _tableService = new TableServiceClient(_opts.ConnectionString);
            // ensure tables exist
            CreateTableIfNotExists(_opts.Tables?.Customers ?? "customers");
            CreateTableIfNotExists(_opts.Tables?.Products ?? "products");
            CreateTableIfNotExists(_opts.Tables?.Orders ?? "orders");
            CreateTableIfNotExists(_opts.Tables?.Payments ?? "payments");
        }

        private TableClient GetTableClient(string tableName)
        {
            var client = _tableService.GetTableClient(tableName);
            client.CreateIfNotExists();
            return client;
        }

        private void CreateTableIfNotExists(string? name)
        {
            if (string.IsNullOrEmpty(name)) return;
            _tableService.CreateTableIfNotExists(name);
        }

        // PRODUCTS
        public async Task CreateOrUpdateProductAsync(ProductEntity p)
        {
            var tbl = GetTableClient(_opts.Tables!.Products!);
            if (string.IsNullOrEmpty(p.RowKey)) p.RowKey = Guid.NewGuid().ToString();
            await tbl.UpsertEntityAsync(p);
        }

        public async Task<List<ProductEntity>> GetProductsAsync()
        {
            var tbl = GetTableClient(_opts.Tables!.Products!);
            var list = new List<ProductEntity>();
            await foreach (var item in tbl.QueryAsync<ProductEntity>()) list.Add(item);
            return list;
        }

        public async Task<ProductEntity?> GetProductAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Products!);
            try
            {
                var res = await tbl.GetEntityAsync<ProductEntity>("Product", rowKey);
                return res.Value;
            }
            catch { return null; }
        }

        public async Task DeleteProductAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Products!);
            await tbl.DeleteEntityAsync("Product", rowKey);
        }

        // USERS / CUSTOMERS
        public async Task CreateOrUpdateUserAsync(UserEntity u)
        {
            var tbl = GetTableClient(_opts.Tables!.Customers!);
            if (string.IsNullOrEmpty(u.RowKey)) u.RowKey = Guid.NewGuid().ToString();
            await tbl.UpsertEntityAsync(u);
        }

        public async Task<List<UserEntity>> GetUsersAsync()
        {
            var tbl = GetTableClient(_opts.Tables!.Customers!);
            var list = new List<UserEntity>();
            await foreach (var item in tbl.QueryAsync<UserEntity>()) list.Add(item);
            return list;
        }

        public async Task<UserEntity?> GetUserAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Customers!);
            try
            {
                var res = await tbl.GetEntityAsync<UserEntity>("Customer", rowKey);
                return res.Value;
            }
            catch { return null; }
        }

        public async Task DeleteUserAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Customers!);
            await tbl.DeleteEntityAsync("Customer", rowKey);
        }

        // ORDERS
        public async Task CreateOrderAsync(OrderEntity o)
        {
            var tbl = GetTableClient(_opts.Tables!.Orders!);
            if (string.IsNullOrEmpty(o.RowKey)) o.RowKey = Guid.NewGuid().ToString();
            await tbl.AddEntityAsync(o);
        }

        public async Task<List<OrderEntity>> GetOrdersAsync()
        {
            var tbl = GetTableClient(_opts.Tables!.Orders!);
            var list = new List<OrderEntity>();
            await foreach (var item in tbl.QueryAsync<OrderEntity>()) list.Add(item);
            return list;
        }

        public async Task<OrderEntity?> GetOrderAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Orders!);
            try
            {
                var res = await tbl.GetEntityAsync<OrderEntity>("Order", rowKey);
                return res.Value;
            }
            catch { return null; }
        }

        public async Task DeleteOrderAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Orders!);
            await tbl.DeleteEntityAsync("Order", rowKey);
        }

        // PAYMENTS
        public async Task CreateOrUpdatePaymentAsync(PaymentEntity p)
        {
            var tbl = GetTableClient(_opts.Tables!.Payments!);
            if (string.IsNullOrEmpty(p.RowKey)) p.RowKey = Guid.NewGuid().ToString();
            await tbl.UpsertEntityAsync(p);
        }

        public async Task<List<PaymentEntity>> GetPaymentsAsync()
        {
            var tbl = GetTableClient(_opts.Tables!.Payments!);
            var list = new List<PaymentEntity>();
            await foreach (var item in tbl.QueryAsync<PaymentEntity>()) list.Add(item);
            return list;
        }

        public async Task<PaymentEntity?> GetPaymentAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Payments!);
            try
            {
                var res = await tbl.GetEntityAsync<PaymentEntity>("Payment", rowKey);
                return res.Value;
            }
            catch { return null; }
        }

        public async Task DeletePaymentAsync(string rowKey)
        {
            var tbl = GetTableClient(_opts.Tables!.Payments!);
            await tbl.DeleteEntityAsync("Payment", rowKey);
        }
    }
}
